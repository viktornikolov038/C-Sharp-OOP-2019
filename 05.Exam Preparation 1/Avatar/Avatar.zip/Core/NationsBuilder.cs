﻿using System;
using System.Collections.Generic;

public class NationsBuilder
{
    public void AssignBender(List<string> benderArgs)
    {
        //TODO: Add some logic here … 
    }
    public void AssignMonument(List<string> monumentArgs)
    {
        //TODO: Add some logic here … 
    }
    public string GetStatus(string nationsType)
    {
        return "";
    }
    public void IssueWar(string nationsType)
    {
        //TODO: Add some logic here … 
    }
    public string GetWarsRecord()
    {
        return "";
    }

}

