﻿using System;

public class SolarProvider : Provider
{
    public SolarProvider(string id, double energyOutput,string type) : base(id, energyOutput,type)
    {
    }

}

