﻿namespace Problem_15.Drawing_tool
{
    public abstract class CorDraw
    {
        public abstract string Draw();
    }
}
